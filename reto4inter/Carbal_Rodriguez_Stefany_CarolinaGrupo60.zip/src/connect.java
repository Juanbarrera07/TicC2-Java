import java.sql.*;
import java.util.logging.*;
import java.util.ArrayList;
import java.util.List;

public class connect {  

    static Connection connect;
    static String url = "jdbc:sqlite:C:/Users/Stefany/Downloads/src/Data.db";

    public static void Connect(){
        
        try {
            connect = DriverManager.getConnection(url);
            
            if (connect != null) {
                System.out.println("Conexión éxitosa.");
            }   
            
        } catch (SQLException e) {
            System.out.println("La conexión ha fallado\n"+ e.getMessage());
            
        }
    }

    public static void close() {

        try {
            connect.close();
        } catch (SQLException ex) {
            Logger.getLogger(connect.class.getName()).log(Level.SEVERE,null,ex);
        }
    }

    public static void crearDB(String filename){

        String url = "jdbc:sqlite:C:/sqlite/db/" + filename;

        try (Connection connect = DriverManager.getConnection(url)) {
            if (connect != null) {
                DatabaseMetaData meta = connect.getMetaData();
                System.out.println("TEl nombre de la carpeta es: " + meta.getDriverName());
                System.out.println("Base de datos creada con éxito.");
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    public static void CrearTabla(){

        // SQL statement for creating a new table
        String sql = "CREATE TABLE IF NOT EXISTS warehouses (\n"
                + "	name text NOT NULL,\n"
                + "	ID integer PRIMARY KEY,\n"
                + "	Municipio text NOT NULL,\n"
                + "	Tipo de agua text NOT NULL,\n"
                + "	Tipo de cuerpo de agua text NOT NULL,\n"
                + "	IRCA real NOT NULL\n"
                + ");";
        
        try (Connection connect = DriverManager.getConnection(url);
                Statement stmt = connect.createStatement()) {
            // create a new table
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    public static void Insertar_Datos(String nombre, Integer id, String municipio, String tipo_agua, String tipo_cuerpo, Double Irca){

        try (Connection connect = DriverManager.getConnection(url)) {

            if (connect != null) {
                Statement stmt = (Statement) connect.createStatement();

                String insertar = "INSERT INTO Data_Table(Nombre, ID, Municipio, [Tipo de Agua], [Tipo cuerpo de agua], IRCA)    VALUES(' "+nombre+"', '"+id+"', '"+municipio+"', '"+tipo_agua+"', '"+tipo_cuerpo+"', '"+Irca+"')";

                stmt.executeUpdate(insertar);
            }
        } 
        catch (SQLException e) {
            System.out.println("Error en la inserción de los datos.\n"+e.getMessage());
        }

    }

    public static void Eliminar_dato(Integer id){

        try (Connection connect = DriverManager.getConnection(url)) {

            if (connect != null) {
                Statement stmt = (Statement) connect.createStatement();

                String eliminar = "DELETE FROM Data_Table WHERE ID ="+id;
                stmt.executeUpdate(eliminar);
            }
        } 
        catch (SQLException e) {
            System.out.println("Error en la inserción de los datos.\n"+e.getMessage());
        }
    }

    public static void Editar_datos(Integer ID_Busqueda, String nombre, Integer id, String municipio, String tipo_agua, String tipo_cuerpo, Double Irca){

        try (Connection connect = DriverManager.getConnection(url)) {

            if (connect != null) {
                Statement stmt = (Statement) connect.createStatement();

                String editar = "UPDATE Data_Table SET Nombre = ' "+nombre+"', ID ='"+id+"', Municipio ='"+municipio+"', [Tipo de agua] = '"+tipo_agua+"', [Tipo cuerpo de agua] = '"+tipo_cuerpo+"', IRCA = '"+Irca+"' WHERE ID = "+ID_Busqueda;
                
                stmt.executeUpdate(editar);
            }
        } 
        catch (SQLException e) {
            System.out.println("Error en la inserción de los datos.\n"+e.getMessage());
        }

    }

    public static Integer Buscar_Existencia(String campo, String valor){
        int resp = 0;

        try (Connection connect = DriverManager.getConnection(url)) {

            if (connect != null) {
                Statement stmt = (Statement) connect.createStatement();

                String buscar = "SELECT count(*) FROM Data_Table WHERE "+campo+" like "+valor;

                ResultSet resultado = stmt.executeQuery(buscar);

                while(resultado.next()){
                    resp = resultado.getInt("count(*)");
                    return resp;
                }
            }
        } 
        catch (SQLException e) {
            resp = -1;
            System.out.println(e);
        }
        return resp;

    }

    public static Integer tabla_vacia(){
        int resp = 0;

        try (Connection connect = DriverManager.getConnection(url)) {

            if (connect != null) {
                Statement stmt = (Statement) connect.createStatement();

                String buscar = "SELECT count(*) FROM Data_Table";

                ResultSet resultado = stmt.executeQuery(buscar);

                while(resultado.next()){
                    resp = resultado.getInt("count(*)");
                    return resp;
                }
            }
        } 
        catch (SQLException e) {
            resp = -1;
            System.out.println(e);
        }
        return resp;

    }

    public static List<String[]> Obtener_Datos(){

        String nombre;
        Integer id;
        String municipio;
        String tipo_agua;
        String tipo_cuerpo;
        Double irca;
        //ArrayList<String> datos_individuales = new ArrayList<String>();
        List<String[]> datos_individuales = new ArrayList<String[]>();


        try (Connection connect = DriverManager.getConnection(url)) {

            if (connect != null) {
                Statement stmt = (Statement) connect.createStatement();

                String buscar_datos = "SELECT * FROM Data_Table";

                ResultSet datos_tabla = stmt.executeQuery(buscar_datos);

                while(datos_tabla.next()){
                    nombre = datos_tabla.getString("Nombre");
                    id = datos_tabla.getInt("ID");
                    municipio = datos_tabla.getString("Municipio");
                    tipo_agua = datos_tabla.getString("Tipo de agua");
                    tipo_cuerpo = datos_tabla.getString("Tipo cuerpo de agua");
                    irca = datos_tabla.getDouble("IRCA");

                    datos_individuales.add(new String[] {nombre, String.valueOf(id),municipio, tipo_agua, tipo_cuerpo, String.valueOf(irca)});
                }
                return datos_individuales;
            }
        } 
        catch (SQLException e) {
            System.out.println(e);
        }
        return datos_individuales;
        

    }


    public static List<String> busqueda_id(Integer id_busqueda){

        String nombre;
        Integer id;
        String municipio;
        String tipo_agua;
        String tipo_cuerpo;
        Double irca;
        List<String> lista_datos = new ArrayList<String>();


        try (Connection connect = DriverManager.getConnection(url)) {

            if (connect != null) {
                Statement stmt = (Statement) connect.createStatement();

                String buscar_datos = "SELECT * FROM Data_Table WHERE ID = "+id_busqueda;

                ResultSet datos_tabla = stmt.executeQuery(buscar_datos);

                while(datos_tabla.next()){
                    nombre = datos_tabla.getString("Nombre");
                    id = datos_tabla.getInt("ID");
                    municipio = datos_tabla.getString("Municipio");
                    tipo_agua = datos_tabla.getString("Tipo de agua");
                    tipo_cuerpo = datos_tabla.getString("Tipo cuerpo de agua");
                    irca = datos_tabla.getDouble("IRCA");

                    lista_datos.add(nombre);
                    lista_datos.add(String.valueOf(id));
                    lista_datos.add(municipio);
                    lista_datos.add(tipo_agua);
                    lista_datos.add(tipo_cuerpo);
                    lista_datos.add(String.valueOf(irca));
                    return lista_datos;
                }
            }
        } 
        catch (SQLException e) {
            System.out.println(e);
        }
        return lista_datos;
        

    }


    public static List<String[]> nombre_irca(){

        String nombre;
        Double irca;
        List<String[]> datos_individuales = new ArrayList<String[]>();


        try (Connection connect = DriverManager.getConnection(url)) {

            if (connect != null) {
                Statement stmt = (Statement) connect.createStatement();

                String buscar_datos = "SELECT * FROM Data_Table";

                ResultSet datos_tabla = stmt.executeQuery(buscar_datos);

                while(datos_tabla.next()){
                    nombre = datos_tabla.getString("Nombre");
                    irca = datos_tabla.getDouble("IRCA");

                    datos_individuales.add(new String[] {nombre, String.valueOf(irca)});
                }
                return datos_individuales;
            }
        } 
        catch (SQLException e) {
            System.out.println(e);
        }
        return datos_individuales;
    }

    public static List<Double> lista_irca(){

        Double irca;
        List<Double> lista_datos = new ArrayList<Double>();


        try (Connection connect = DriverManager.getConnection(url)) {

            if (connect != null) {

                Statement stmt = (Statement) connect.createStatement();
                String buscar_datos = "SELECT * FROM Data_Table";
                ResultSet datos_tabla = stmt.executeQuery(buscar_datos);

                while(datos_tabla.next()){
                    irca = datos_tabla.getDouble("IRCA");

                    lista_datos.add(irca);
                }
                return lista_datos;
            }
        } 
        catch (SQLException e) {
            System.out.println(e);
        }
        return lista_datos;
    }

    public static List<String> lista_nombres(){

        String nombre;
        List<String> lista_datos = new ArrayList<String>();


        try (Connection connect = DriverManager.getConnection(url)) {

            if (connect != null) {

                Statement stmt = (Statement) connect.createStatement();
                String buscar_datos = "SELECT * FROM Data_Table";
                ResultSet datos_tabla = stmt.executeQuery(buscar_datos);

                while(datos_tabla.next()){
                    nombre = datos_tabla.getString("Nombre");

                    lista_datos.add(nombre);
                }
                return lista_datos;
            }
        } 
        catch (SQLException e) {
            System.out.println(e);
        }
        return lista_datos;
    }


    
    public static void main(String[] args) {
        Connect();
        close();
        
    }

}
