package reto_cuatro;

//import java.util.ArrayList;
import java.util.List;

public class CuerpoDeAgua extends ObjetoGeografico {

    public CuerpoDeAgua(){}

    public String nivel(List <Double> datos_irca, List <String> datos_nombre){
        

        for (int i = 0; i < datos_irca.size(); i++){
            if (datos_irca.get(i) >= 35.1 && datos_irca.get(i) <= 80){
                datos_nivel.add(datos_nombre.get(i));
            }
        } 

        if (datos_nivel.size() > 0){
            result = datos_nivel.toString().replaceAll("\\[|\\]", "").replaceAll(", "," ");      
        }
        else {
            result = "NA";
        }
        return result;
    }

    //String result;
    //List <String> datos_nivel = new ArrayList<String>();
    
}