package reto_cuatro;

import java.util.ArrayList;
import java.util.List;

public class ObjetoGeografico{

    String result;
    List <String> datos_nivel = new ArrayList<String>();

    public ObjetoGeografico(){}

}