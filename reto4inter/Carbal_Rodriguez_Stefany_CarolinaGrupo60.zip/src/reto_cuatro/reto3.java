package reto_cuatro;

/*
En cuanto al diseño del programa se debe realizar lo siguiente:
•	Implementar POO creando una superclase llamada ObjetoGeografico.
•	Implementar POO creando una subclase llamada CuerpoDeAgua que extienda de ObjetoGeografico.
•	Implementar un método dentro de la clase CuerpoDeAgua llamado nivel que calcule el nivel de riesgo de un cuerpo de agua de acuerdo con los valores de la instancia. 
•	Implementar una clase llamada reto3 en donde se soliciten los datos por consola y se encuentre el método principal de ejecución del programa, y donde se instancien los objetos de tipo CuerpoDeAgua.

*/

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class reto3 {
    public static void main(String[] args) throws Exception {
        
        Scanner read_input = new Scanner(System.in);

        // Leer la cantidad de cuerpos de agua a analizar como string y convertir a int.

        String lap_input = read_input.nextLine();
        int lap_input_int = Integer.parseInt(lap_input);

        Float contador_irca = 0f;
        List <Double> datos_irca = new ArrayList<Double>();
        List <String> datos_nombre = new ArrayList<String>();
        List <String> clasificacion_alta = new ArrayList<String>();

        while (lap_input_int > 0){
        
            String calidad = read_input.nextLine();
            String[] lista_datos = calidad.split(" ");
            datos_irca.add(irca_num(lista_datos));
            datos_nombre.add(lista_datos[0]);
            
        lap_input_int--;

        }

        // IMPRIMIR NOMBRE DEL CUERPO DE AGUA Y SU CLASIFICACIÓN IRCA.
        
        for (int i = 0; i < datos_nombre.size(); i++){
            System.out.printf(datos_nombre.get(i) + " " + "%.2f%n", datos_irca.get(i));
        }

        // CUERPOS QUE TIENEN UNA CLASIFICACIÓN IRCA MAYOR A 50. 
        for (Double x : datos_irca){
            if (x >= 50){
                contador_irca++;
            }
        }
        System.out.printf("%.2f%n",contador_irca); // ARREGLAR

        // CUERPOS DE AGUA QUE TIENEN UN NIVEL DE RIESGO "ALTO".

        CuerpoDeAgua nivel_riesgo = new CuerpoDeAgua();
        System.out.println(nivel_riesgo.nivel(datos_irca, datos_nombre));

        // IRCA MÁS ALTO DE TODOS LOS CUERPOS DE AGUA INGRESADOS.
        Double max = 0.00;

        for (int i = 0; i < datos_irca.size(); i++){
            if (datos_irca.get(i) > max) {
                max = datos_irca.get(i);}
        }
        System.out.printf("%.2f%n",max);

    }
    
    public static Double irca_num(String[] datos){
        Double irca = Double.parseDouble(datos[5]);
        return irca;
    }
}