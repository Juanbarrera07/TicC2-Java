import java.util.List;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import reto_cuatro.CuerpoDeAgua;

public class Controller extends connect {

    public void alarma(String error_exito, String mensaje){
        Alert alert;
        alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Reto 4 - Mintic");
        alert.setHeaderText(error_exito);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    @FXML
    private TextField IngresarNombre;

    @FXML
    private Button BtnIngresar;

    @FXML
    private TextField IngresarID;

    @FXML
    private TextField IngresarMunicipio;

    @FXML
    private TextField IngresarTipoDeAgua;

    @FXML
    private TextField IngresarTipoDeCuerpoDeAgua;

    @FXML
    private TextField IngresarIRCA;

    @FXML
    private TextArea ContenedorObtenerDatos;

    @FXML
    private TextArea ContenedorProcesarDatos;

    @FXML
    private Button BtnObtenerDatos;

    @FXML
    private Button BtnProcesarDatos;

    @FXML
    private TextField ResultadoIRCA;

    @FXML
    private Button BtnEditar;

    @FXML
    private Button btnEliminar;

    @FXML
    private TextField ResultadoTipoCuerpo;

    @FXML
    private TextField ResultadoTipoAgua;

    @FXML
    private TextField ResultadoMunicipio;

    @FXML
    private TextField ResultadoID;

    @FXML
    private TextField ResultadoNombre;

    @FXML
    private TextField BuscarID;

    @FXML
    private Button BtnBuscar;

    @FXML
    void ActivarDesactivar(KeyEvent event) {
        
        if (!BuscarID.getText().trim().isEmpty()){
            BtnEditar.setDisable(false);
            btnEliminar.setDisable(false);
            BtnBuscar.setDisable(false);
        }
        else{
            BtnEditar.setDisable(true);
            btnEliminar.setDisable(true);
            BtnBuscar.setDisable(true);
        }
    }

    @FXML
    void BotonBuscar(ActionEvent event) {

        int tabla_bc = tabla_vacia();

        if (tabla_bc != 0){
            
            String search_id = BuscarID.getText().trim();

            if (search_id.matches("[0-9]*")){
                Integer id_conteo = Buscar_Existencia("ID", search_id);

                if (id_conteo <= 0){
                    
                    alarma("ERROR","El ID que digitó no existe.");
                }
                else {
    
                    BtnEditar.setDisable(false);
                    btnEliminar.setDisable(false);
            
                    List <String> datos_ind =  busqueda_id(Integer.parseInt(search_id));
                
                        ResultadoNombre.setText(datos_ind.get(0));
                        ResultadoID.setText(datos_ind.get(1));
                        ResultadoMunicipio.setText(datos_ind.get(2));
                        ResultadoTipoAgua.setText(datos_ind.get(3));
                        ResultadoTipoCuerpo.setText(datos_ind.get(4));
                        ResultadoIRCA.setText(datos_ind.get(5));
                
                        ResultadoNombre.setEditable(true);
                        ResultadoID.setEditable(true);
                        ResultadoMunicipio.setEditable(true);
                        ResultadoTipoAgua.setEditable(true);
                        ResultadoTipoCuerpo.setEditable(true);
                        ResultadoIRCA.setEditable(true);
                    }    
                }
            else {
                alarma("ADVERTENCIA","El ID debe corresponder a un valor entero");
            }
        }
        else {
            alarma("ERROR","No hay datos registrados en la base de datos.");
        }
    }

    @FXML
    void BotonEditar(ActionEvent event) {

        String search_id = BuscarID.getText().trim();

        String search_nombre = ResultadoNombre.getText().trim();
        String search_id_cuerpo = ResultadoID.getText().trim();
        String search_municipio = ResultadoMunicipio.getText().trim();
        String search_tipo_agua = ResultadoTipoAgua.getText().trim();
        String search_tipo_cuerpo = ResultadoTipoCuerpo.getText().trim();
        String search_irca = ResultadoIRCA.getText().trim().replace(",", ".");
        Boolean isNumeric_id =  search_id_cuerpo.matches("[0-9]*");
        Boolean isNumeric_irca = search_irca.matches("[+-]?\\d*(\\.\\d+)?");

        if (search_nombre.isEmpty() || search_id_cuerpo.isEmpty() || search_municipio.isEmpty() || search_tipo_agua.isEmpty() || search_tipo_cuerpo.isEmpty() || search_irca.isEmpty()){
            
            alarma("ERROR", "Debe rellenar todos los campos.");
        }
        else {
            if (isNumeric_id == false || isNumeric_irca == false){

                alarma("ERROR", "El campo 'ID' e 'IRCA' deben corresponder a valores numéricos.\nRecuerde asignar un número entero positivo en el campo 'ID'.");

            }
            else {
                Integer id_conteo = Buscar_Existencia("ID", search_id_cuerpo);
    
                if (id_conteo < 0){
                    
                    Editar_datos(Integer.parseInt(search_id), search_nombre, Integer.parseInt(search_id_cuerpo), search_municipio, search_tipo_agua, search_tipo_cuerpo, Double.parseDouble(search_irca));

                    alarma("OPERACIÓN ÉXITOSA", "Los datos fueron actualizados satisfactoriamente.");
                    
                    ResultadoNombre.setText("");
                    ResultadoID.setText("");
                    ResultadoMunicipio.setText("");
                    ResultadoTipoAgua.setText("");
                    ResultadoTipoCuerpo.setText("");
                    ResultadoIRCA.setText("");
                    BuscarID.setText("");

                    BtnEditar.setDisable(true);
                    btnEliminar.setDisable(true);
                }
                else {

                    alarma("ERROR", "El ID ya se encuentra registrado, por favor ingrese otro valor.");
                    
                }
            }
        }
    }

    @FXML
    void BotonEliminar(ActionEvent event) {

        String id_find = BuscarID.getText().trim();
        Integer id_conteo = Buscar_Existencia("ID", id_find);
        
        if (id_find.matches("[0-9]*")){

            if (id_conteo > 0){
                Eliminar_dato(Integer.parseInt(id_find));

                alarma("OPERACIÓN ÉXITOSA", "El ingreso con ID "+id_find+" fue eliminado.");

                ResultadoNombre.setText("");
                ResultadoID.setText("");
                ResultadoMunicipio.setText("");
                ResultadoTipoAgua.setText("");
                ResultadoTipoCuerpo.setText("");
                ResultadoIRCA.setText("");
                BuscarID.setText("");

                BtnEditar.setDisable(true);
                btnEliminar.setDisable(true);
                    
            }
            else {
                alarma("ERROR","El ID que digitó no existe.");
            }
        }
    }

    @FXML
    void BotonIngresar(ActionEvent event) {

        String nombre = IngresarNombre.getText().trim();
        String id_cuerpo = IngresarID.getText().trim();
        String municipio = IngresarMunicipio.getText().trim();
        String tipo_agua = IngresarTipoDeAgua.getText().trim();
        String tipo_cuerpo = IngresarTipoDeCuerpoDeAgua.getText().trim();
        String irca = IngresarIRCA.getText().trim().replace(",", ".");
        Boolean isNumeric_id =  id_cuerpo.matches("[0-9]*");
        Boolean isNumeric_irca = irca.matches("[+-]?\\d*(\\.\\d+)?");

        if (nombre.isEmpty() || id_cuerpo.isEmpty() || municipio.isEmpty() || tipo_agua.isEmpty() || tipo_cuerpo.isEmpty() || irca.isEmpty()){
            
            alarma("ADVERTENCIA", "Debe rellenar todos los campos.");
        }
        else if (isNumeric_id == false || isNumeric_irca == false){

            alarma("ERROR", "El campo ID e IRCA deben corresponder a un valor numérico.\nRecuerde que debe asignar un número entero positivo al ID.");

        }
        else {
            Integer id_conteo = Buscar_Existencia("ID", id_cuerpo);

            if (id_conteo > 0){
                
                alarma("ERROR", "El ID ya se encuentra registrado, por favor ingrese otro valor.");
    
            }
            else {
                Insertar_Datos(nombre, Integer.parseInt(id_cuerpo), municipio, tipo_agua, tipo_cuerpo, Double.parseDouble(irca));

                alarma("ATENCIÓN", "Registro éxitoso.");
                    
                IngresarNombre.setText("");
                IngresarMunicipio.setText("");
                IngresarID.setText("");
                IngresarTipoDeAgua.setText("");
                IngresarTipoDeCuerpoDeAgua.setText("");
                IngresarIRCA.setText("");
                    
            }
        }     
    }

    @FXML
    void BotonObtenerDatos(ActionEvent event) {

        int tabla = tabla_vacia();

        if (tabla != 0){

            BtnProcesarDatos.setDisable(false);
            ContenedorObtenerDatos.setText("");

            List<String[]> datos_recopilados = Obtener_Datos();

            for (String[] x : datos_recopilados){
                for (String i : x){
                    ContenedorObtenerDatos.appendText(i+" ");
                }
                ContenedorObtenerDatos.appendText("\n");
            }
        }
        else {
            ContenedorObtenerDatos.setText("");
            ContenedorProcesarDatos.setText("");
            alarma("ERROR", "Usted no ha realizado ningún ingreso en la base de datos.");
        }
    }

    @FXML
    void BotonProcesarDatos(ActionEvent event) {

        int tabla = tabla_vacia();

        if (tabla != 0){

            ContenedorProcesarDatos.setText("");

            List <String[]> lista_nombres_irca = nombre_irca();
            for (String[] x : lista_nombres_irca){
                for (String i : x){
                    ContenedorProcesarDatos.appendText(" "+i);
                }
                ContenedorProcesarDatos.appendText("\n");
            }

            List <Double> datos_irca = lista_irca();
            List <String> datos_nombre = lista_nombres();
            Double count = 0.00;

            for(Double i : datos_irca){
                if (i >= 50){
                    count++;
                }
            }
            ContenedorProcesarDatos.appendText(" "+String.valueOf(count));

            CuerpoDeAgua irca_valor = new CuerpoDeAgua();
            
            ContenedorProcesarDatos.appendText("\n"+ irca_valor.nivel(datos_irca, datos_nombre));

            Double max = 0.00;

            for (int i = 0; i < datos_irca.size(); i++){
                if (datos_irca.get(i) > max) {
                    max = datos_irca.get(i);}
            }
            ContenedorProcesarDatos.appendText("\n"+" "+ String.valueOf(max));
        }
        else {
            ContenedorObtenerDatos.setText("");
            ContenedorProcesarDatos.setText("");
            alarma("ERROR", "Usted no ha realizado ningún ingreso en la base de datos.");
        }
    }
}